package edu.umd.radham95.cmsc436_project;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.ExecutionException;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.client.methods.HttpGet;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

/**
 * Created by Radha.
 */

public class MealFragment extends Fragment {
    static ViewGroup rootView;
    private static final String TAG = "Meal Fragment";
    private EditText mCalories;
    private EditText mLabel;
    private CheckBox mCheck;
    static private final int FAVORITE_REQUEST = 3;
    String calor = "";
    String prod_descr = "";
    private ImageButton scanBtn;
    String xxmmll = "";
    String formatTxt = "";
    String contentTxt = "";
Fragment f = (Fragment)this;
    //String tag = getSupportFragmentManager().getBackStackEntryAt(getSupportFragmentManager().getBackStackEntryCount() - 1).getName();
   // return getSupportFragmentManager().findFragmentByTag(tag);

   IntentIntegrator scanIntegrator = new IntentIntegrator(this.getActivity());


    public MealFragment() {
        super();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.v(TAG, "Meal Fragment selected");

        rootView = (ViewGroup) inflater.inflate(R.layout.add_meal, container, false);

        mLabel = (EditText) rootView.findViewById(R.id.foodItemEditText);
        mCalories = (EditText) rootView.findViewById(R.id.caloriesEditText);
        mCheck = (CheckBox) rootView.findViewById(R.id.FavoriteCheckBox);
       final IntentIntegrator scanIntegrator = new IntentIntegrator(this.getActivity());

        final Button submitButton = (Button) rootView.findViewById(R.id.submit);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String label = getLabel();
                String calories = getCalories();

                Intent data = new Intent();
                data.putExtra("Label", label);
                data.putExtra("Calories", calories);

                if (mCheck.isChecked()) {
                    data.putExtra("Checked", "true");
                } else {
                    data.putExtra("Checked", "false");
                }

                getActivity().setResult(Activity.RESULT_OK, data);
                getActivity().finish();
            }
        });

        final ImageButton favoriteButton = (ImageButton) rootView.findViewById(R.id.Favorite_list);
        favoriteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), FavoriteActivity.class);
                startActivityForResult(intent, FAVORITE_REQUEST);
            }
        });


        scanBtn = (ImageButton) rootView.findViewById(R.id.Barcode_scanner);


        scanBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                System.out.println("Clicked");

                if (v.getId() == R.id.Barcode_scanner) {
                    System.out.println("IF Statement");

                    //  Intent intent = new Intent();
                    // intent.putExtra("calor","");
                    // intent.putExtra("prod_descr", "");

                    // setResult(RESULT_OK, intent);

                    scanIntegrator.initiateScan();
                    if (((!formatTxt.equals(null)) && (!contentTxt.equals(null))) &&
                         ((!formatTxt.equals("")) && (!contentTxt.equals(""))) &&
                            ((!formatTxt.equals("null")) && (!contentTxt.equals("null")))) {

                        String xml_string = "";

                        //TODO - Add the check for a UPC and grab those fields after activity result, rework this string
                        String url = "https://api.nutritionix.com/v1_1/item?upc="+ contentTxt+"&appId=5d2d1db4&appKey=00bdcc01de4f82fb26b8402ed0d9da55";
                        URL urlll;
                        try {
                            urlll = new URL(url);
                            try {
                                xxmmll = new DownloadTask().execute(urlll).get();
                                System.out.println("IF Statement");
                                if (xxmmll.equals("")) {
                                    System.out.println("IF Statement NULL");

                                }
                                //      System.out.println(xxmmll);

                            } catch (InterruptedException e) {

                            } catch (ExecutionException e) {

                            }


                        } catch (MalformedURLException e) {

                            e.printStackTrace();
                        }


                        try {


//xxmmll = "{\"old_api_id\":null,\"item_id\":\"51c3d78797c3e6d8d3b546cf\",\"item_name\":\"Cola, Cherry\",\"leg_loc_id\":9999999,\"brand_id\":\"51db3801176fe9790a89ae0b\",\"brand_name\":\"Coke\",\"item_description\":\"Cherry\",\"updated_at\":\"2014-11-24T20:24:24.000Z\",\"nf_ingredient_statement\":\"Carbonated Water, High Fructose Corn Syrup and/or Sucrose, Caramel Color, Phosphoric Acid, Natural Flavors, Caffeine.\",\"nf_water_grams\":null,\"nf_calories\":100,\"nf_calories_from_fat\":0,\"nf_total_fat\":0,\"nf_saturated_fat\":null,\"nf_trans_fatty_acid\":null,\"nf_polyunsaturated_fat\":null,\"nf_monounsaturated_fat\":null,\"nf_cholesterol\":null,\"nf_sodium\":25,\"nf_total_carbohydrate\":28,\"nf_dietary_fiber\":null,\"nf_sugars\":28,\"nf_protein\":0,\"nf_vitamin_a_dv\":0,\"nf_vitamin_c_dv\":0,\"nf_calcium_dv\":0,\"nf_iron_dv\":0,\"nf_refuse_pct\":null,\"nf_servings_per_container\":6,\"nf_serving_size_qty\":8,\"nf_serving_size_unit\":\"fl oz\",\"nf_serving_weight_grams\":null,\"allergen_contains_milk\":null,\"allergen_contains_eggs\":null,\"allergen_contains_fish\":null,\"allergen_contains_shellfish\":null,\"allergen_contains_tree_nuts\":null,\"allergen_contains_peanuts\":null,\"allergen_contains_wheat\":null,\"allergen_contains_soybeans\":null,\"allergen_contains_gluten\":null,\"usda_fields\":null}";
                            // File fXmlFile = new File(xxmmll);
                            boolean checker = false;
                        if(xxmmll != null) {

                            String[] spl = xxmmll.split(",");

                            for (int i = 0; i < spl.length; i++) {
                                if (spl[i].contains("nf_calories\"")) {
                                    String[] c = spl[i].split(":");
                                    calor = c[1];
                                    //System.out.println(calor);
                                    checker = true;
                                    mCalories.setText(calor);

                                }
                            }

                           // if (checker == false) {
                           //     Toast tt = Toast.makeText(getContext(), "No result for that item", Toast.LENGTH_LONG);
                           //     tt.show();
                           // }

                            String[] spl2 = xxmmll.split(",");
                            for (int i = 0; i < spl2.length; i++) {
                                if (spl2[i].contains("item_name")) {
                                    String[] c = spl2[i].split(":");
                                    prod_descr = c[1];
                                    prod_descr = prod_descr.replace("\"", "");
                                    // System.out.println(prod_descr);

                                    mLabel.setText(prod_descr);

                                }
                            }

                        }

/*

                        if(!(xxmmll.contains("country"))) {
                            Toast tt = Toast.makeText(getApplicationContext(), "No country", Toast.LENGTH_SHORT);
                            tt.show();
                        }*/
                        /*
                        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                        InputSource is = new InputSource();
                        is.setCharacterStream(new StringReader(xxmmll));

                        Document doc = dBuilder.parse(is);
                        doc.getDocumentElement().normalize();



                        NodeList nnL = doc.getElementsByTagName("geoname");



                        for (int temp = 0; temp < nnL.getLength(); temp++) {

                            Node nNode = nnL.item(temp);




                            if (nNode.getNodeType() == Node.ELEMENT_NODE) {

                                Element lement = (Element) nNode;

                                // System.out.println("Staff id : " + eElement.getAttribute("id"));
                                name= lement.getElementsByTagName("name").item(0).getTextContent();
                                countryName =  lement.getElementsByTagName("countryName").item(0).getTextContent();

                                Intent inte = new Intent();

                                System.out.println(name);
                                System.out.println(lement.getElementsByTagName("name").item(0).getTextContent());
*/
                            // Intent inte = new Intent();
                            //      intent.putExtra("calor",calor);
                            //      intent.putExtra("prod_descr",prod_descr);
//
                            //      setResult(RESULT_OK, intent);
                            // finish();

                            //  mCalories.setText("100");
                            //  mLabel.setText("Cola");

                        } catch (Exception e) {
                            e.printStackTrace();
                        }



                    } else {
                                Toast tt = Toast.makeText(getContext(), "No result for that item", Toast.LENGTH_LONG);
                                tt.show();
                            }

                }
            }
        })
        ;

        return rootView;

    }


    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        if (requestCode == FAVORITE_REQUEST && resultCode == Activity.RESULT_OK) {
            Meal meal = new Meal(intent);
            String mealLabel = meal.getName();
            String mealCalories = meal.getCalories();

            mLabel.setText(mealLabel);
            mCalories.setText(mealCalories);
        } else {
            IntentResult scanningResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, intent);
            if (scanningResult != null) {
                String scanContent = scanningResult.getContents();
                String scanFormat = scanningResult.getFormatName();
                formatTxt = scanFormat;
                contentTxt = scanContent;
//we have a result
            } else {
                Toast toast = Toast.makeText(getContext(),
                        "No scan data received!", Toast.LENGTH_SHORT);
                toast.show();
            }
        }

    }

    private String getLabel() {
        return mLabel.getText().toString();
    }

    private String getCalories() {
        return mCalories.getText().toString();
    }


    public void setXML(String xml) {
        xxmmll = xml;
    }

    private class DownloadTask extends AsyncTask<URL, Integer, String> {
        protected String doInBackground(URL... urls) {
            String xmll = "";
            try {
/*
            String urll = urls[0].toString();
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(urll);
            HttpResponse httpResponse = httpClient.execute(httpPost);
            HttpEntity httpEntity = httpResponse.getEntity();
            xmll = EntityUtils.toString(httpEntity);
            return xmll;
            */
                DefaultHttpClient defaultClient = new DefaultHttpClient();
// Setup the get request
                HttpGet httpGetRequest = new HttpGet(urls[0].toString());

// Execute the request in the client
                HttpResponse httpResponse = defaultClient.execute(httpGetRequest);
// Grab the response
                BufferedReader reader = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent(), "UTF-8"));
                String json = reader.readLine();
                return json;
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return xmll;
        }

        protected void onProgressUpdate(Integer... progress) {

        }

        protected void onPostExecute(String result) {

            setXML(result);
        }
    }
}
