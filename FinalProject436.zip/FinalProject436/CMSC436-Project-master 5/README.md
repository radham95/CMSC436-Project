# CMSC436-Project
Spring 2016

Daily calorie tracker that provides healthy dietary guidelines for better nutrition management for people challenged by obesity.

Group Members
Nicholas Davis, 
Raymond Smoley, 
Radha Ranasinghe
